//
//  flights.swift
//  Airline
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//
import Foundation

//conforming to protocol IDisplay
class Customer : IDisplay{
    var customerID : String?
    private var customerName : String?
    private var address : String?
    private var email : String?
    private var contact : String?
   
    
    //Getter - Setter
    var getCustomerName : String?{
        get{ return self.customerName}
        set{  self.customerName = newValue }
    }
    var getEmail : String?{
        get { return self.email}
        set {self.email = newValue}
    }
    var getAddress : String?{
        get { return self.address}
        set {self.address = newValue}
    }
    var getContact : String?{
        get { return self.contact}
        set {self.contact = newValue}
    }
    
    //default initializer / constructor
    init(){
        self.customerID = ""
        self.customerName = ""
        self.email = ""
        self.address = ""
        self.contact = ""
        
    }
    
    
    func displayData() -> String{
        var returnData = ""
        
        if self.customerID != nil{
            returnData += "\n Customer ID : " + self.customerID!
        }
        if self.customerName != nil{
            returnData += "\n Customer Name : " + self.customerName!
        }
        if self.email != nil{
            returnData += "\n Customer Email : " + self.email!
        }
        if self.address != nil{
            returnData += "\n Customer Address : " + self.address!
        }
        if self.contact != nil{
            returnData += "\n Customer Contact : " + self.contact!
        }
        return returnData
    }
    
    func registerUser(){
        print("Enter Customer ID : ")
        self.customerID = readLine()!
        print("Enter Customer Name : ")
        self.customerName = readLine()!
        print("Enter Customer Email : ")
        self.email = readLine()!
        print("Enter Customer Address : ")
        self.address = readLine()!
        print("Enter Customer Contact : ")
        self.contact = readLine()!
    }
}









