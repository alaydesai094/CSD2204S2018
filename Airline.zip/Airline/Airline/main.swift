//
//  main.swift
//  Airline
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var customer = Customer()
customer.registerUser()
// print(customer.displayData())
print("----------------------------------------------------- \n")

print("Welcome to Our Application :  \(customer.getCustomerName ?? "Guest")" )
print("----------------------------------------------------- \n")

print("Please Choose From the 1 - 4 : ")
print("1. My Profile.)

let someNumber = 4

switch someNumber {

case 1:
    
    // view Flight details
    
    let dataHelper = DataHelper()
    dataHelper.displayFlights()
    dataHelper.searchFlights()

default:
    print("Otherwise, do something else.")
}


