//
//  Database.swift
//  Airline
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper{
    var flightList = [Int : Flights]()
    
    init(){
        self.loadFlightData()
    }
    
    func loadFlightData(){
        flightList = [:]
        
        let f1 = Flights(flightID: 101, flightName: "Boing AC2552 ", flightFrom:"Mumbai", flightTo :"Dubhai", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f1.flightID!] = f1
        
        let f2 = Flights(flightID: 102, flightName: "Boing AC2553 ", flightFrom:"Mumbai", flightTo :"Dubhai", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f2.flightID!] = f2
        
        
        let f3 = Flights(flightID: 103, flightName: "Boing AC2554 ", flightFrom:"Mumbai", flightTo :"Dubhai", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f3.flightID!] = f3
 
        let f4 = Flights(flightID: 104, flightName: "Boing AC2554 ", flightFrom:"Mumbai", flightTo :"Bali", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f4.flightID!] = f4
        
        let f5 = Flights(flightID: 105, flightName: "Boing AC2554 ", flightFrom:"Mumbai", flightTo :"Bali", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f5.flightID!] = f5
        
        let f6 = Flights(flightID: 106, flightName: "Boing AC2554 ", flightFrom:"Mumbai", flightTo :"bali", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f6.flightID!] = f6
        
        let f7 = Flights(flightID: 107, flightName: "Boing AC2554 ", flightFrom:"Mumbai", flightTo :"Singapore", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f7.flightID!] = f7
     
        let f8 = Flights(flightID: 108, flightName: "Boing AC2554 ", flightFrom:"Mumbai", flightTo :"Singapore", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f8.flightID!] = f8
        
        let f9 = Flights(flightID: 109, flightName: "Boing AC2554 ", flightFrom:"Mumbai", flightTo :"Singapore", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f9.flightID!] = f9
        
        let f10 = Flights(flightID: 110, flightName: "Boing AC2554 ", flightFrom:"Mumbai", flightTo :"Paris", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f10.flightID!] = f10
        
        let f11 = Flights(flightID: 111, flightName: "Boing AC2554 ", flightFrom:"Mumbai", flightTo :"Paris", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f11.flightID!] = f11
      
        let f12 = Flights(flightID: 112, flightName: "Boing AC2554 ", flightFrom:"Mumbai", flightTo :"Paris", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f12.flightID!] = f12
        
    }
    func displayFlights(){
        for (_, value) in self.flightList.sorted(by: { $0.key < $1.key} ){
            print(value.displayData())
        }
    }
    
    func searchFlights(){
        
       for (_, value) in self.flightList.sorted(by: { $0.key < $1.key} ){
    print(value.displayData())
       }
    }
}

