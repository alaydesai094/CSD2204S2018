//
//  Database.swift
//  Airline
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper{
    var flightList = [Int : Flights]()
    
    init(){
        self.loadFlightData()
    }
    
    func loadFlightData(){
        flightList = [:]
        
        let f1 = Flights(flightID: 101, flightName: "Projector B101 ", flightFrom:"Mumbai", flightTo :"Dubhai", flightSchedule:"Dep : 2:12 am form Terminal 2", flightPilot:"Alex Palmer"    )
        flightList[f1.flightID!] = f1
        
       
    func displayFlights(){
        for (_, value) in self.flightList.sorted(by: { $0.key < $1.key} ){
            print(value.displayData())
        }
    }
}
}
