//
//  DataHelper.swift
//  Book
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper{
    var BookList = [Int : Book ]()
    var UserList = [String : User]()
    
    init() {
        self.loadBookData()
       // self.loadUserData()
    }
    
    func loadBookData(){
        BookList = [:]
        
            let b1 = Book(bookID: 101, title: "Harry Potter", category: BookCategory.Fiction, refundablePrice: 2.5 , authorID: "A101", name: "JK Rowling", country: "USA")
            BookList[(b1.bookID)] = b1
        
        let b2 = Book(bookID: 102, title: "Spilled Milk", category: BookCategory.Fiction, refundablePrice: 1.5 , authorID:"A102", name:  "KLR", country: "USA")
        BookList[(b2.bookID)] = b2
        
        let b3 = Book(bookID: 103, title: "The Cellar", category: BookCategory.Drama, refundablePrice: 3.5 , authorID:"A103" , name: "Natasha Preston", country: "USA")
        BookList[(b3.bookID)] = b3
        
        let b4 = Book(bookID: 104, title: "Unbroken", category: BookCategory.Biography, refundablePrice: 1.0 , authorID:"A104" , name: "Laura Hillenbrand", country: "USA")
        BookList[(b4.bookID)] = b4
        
        let b5 = Book(bookID: 105, title: " Cottage by the Sea ", category: BookCategory.Romance, refundablePrice: 4.5 , authorID:"A105",  name: "Debbie Macomber", country: "USA")
        BookList[(b5.bookID)] = b5
        
        
    }
    
    
    func displayBooks(){
        
        print("\n -----------------------------------------| Booklist |------------------------------------- \n")
        print("\t ID \t\t Name \t\t\t\t Manufecturer \t\t Category \t\t Unit Price \n")
        for (_, value) in self.BookList.sorted(by: { $0.key < $1.key }){
            print("\t \(value.bookID) ------ \(value.title) ------ \(value.category) ------ \(value.refundablePrice) ------ \(value.name)------\(value.country) \n ")    }
    
    }
    
    
    func searchBook(bookID : Int) -> Book?{
        if BookList[bookID] != nil{
            return BookList[bookID]! as Book
        }
        else{
            print("Sorry..The Book number you have entered is not available")
            return nil
        }
    }
    
    
    func loadUserData(){
        UserList = [:]
        
        let u1 = User(userID: "C101", name: "Alay", address: "Don Mills", contactNo: "4562142521", password: "1230")
         UserList[(u1.userID)] = u1
        
        let u2 = User(userID: "C102", name: "Shivam", address: "", contactNo: "4562142521", password: "1230")
        UserList[(u2.userID)] = u2
    
    }
    
    
    
}
