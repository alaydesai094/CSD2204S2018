//
//  Book.swift
//  Book
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Book : Author {
    
    var bookID: Int
    var title : String
    var category : BookCategory
    var refundablePrice : Double
    
    override init(){
        
        self.bookID = 0
        self.title = ""
        self.category = BookCategory.None
        self.refundablePrice = 0.0
        super.init()
        
    }
    
    init(bookID: Int, title: String, category: BookCategory, refundablePrice: Double, authorID: String, name: String, country: String){
        
        self.bookID = bookID
        self.title = title
        self.category = category
        self.refundablePrice = refundablePrice
        super.init()
        
    }
    
     func displayData() -> String{
    
        var returnData = ""
        
        returnData += "\t \(self.bookID ) ------ \(self.title )------ \(self.category )------ \(self.refundablePrice )"
        
        return returnData
    }
}
