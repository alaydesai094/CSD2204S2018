//
//  User.swift
//  Book
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class User{
    var userID: String
    var name : String?
    var address : String
    var contactNo : String
    var password : String?
    
    init(){
        self.userID = ""
        self.name = ""
        self.address = ""
        self.contactNo = ""
        self.password = ""
    }
    
    init(userID: String, name: String, address: String, contactNo: String, password: String){
        self.userID = userID
        self.name = name
        self.address = address
        self.contactNo = contactNo
        self.password = password
    }
    

    func login(){
        
       
        
        print("Enter User Name : ")
        name = readLine()!
        
        print("Enter Password : ")
        password = readLine()!
        
        
    }
    
    
    
    
}
