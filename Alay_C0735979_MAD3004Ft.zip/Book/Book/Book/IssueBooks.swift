//
//  IssueBooks.swift
//  Book
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

typealias bookItem = (bookID : Int, Book : Book)

class IssueBooks : User{
    var issueID : Int
    var issueDate : Date
    var issuedBook : [bookItem]
    var dataHelper = DataHelper()


    override init() {
        self.issueID = 0
        self.issueDate = DateFormatter().date(from: "")!
        self.issuedBook = []
        super.init()
    }


    //computed property
    var RefundAmount: Double?{
        get{
            var amount = 0.0
            if !self.issuedBook.isEmpty{
                for (_, Book) in self.issuedBook{
                    amount += Book.refundablePrice
                }
            }
            return amount
        }
    }
    
    
    
    func displayData() -> String{
        
        var returnData = ""
        
        returnData += "\n Issue ID : \(self.issueID)"
        returnData += "\n Issue Date : \(self.issueDate )"
        returnData = "----------------------------------------------"
        returnData += "\n Book List : "
        returnData = "------------------------------------------------"
        
        if !self.issuedBook.isEmpty{
            for (_, Book) in self.issuedBook{
                returnData += "\n \tBooks : \(Book.displayData())"
            }
        }else{
            returnData += "\n No Books in the Account"
        }
        returnData = "--------------------------------------------------"
        returnData += "\n Amount Payable : \(self.RefundAmount  ?? 0.0)"
        returnData = "--------------------------------------------------"
        
        return returnData
    }

    func addBooks(){
        dataHelper.displayBooks()
        print("Please enter Book ID to Issue any Book from the list : ")
        let selectedBookID : Int = (Int)(readLine()!)!
        
        if let selectedBook = dataHelper.searchBook(bookID: selectedBookID){
            self.issueID = selectedBookID
            self.issueDate = Date()
            
            self.issuedBook += [(bookID: selectedBookID, Book : selectedBook)]
            
            print("\n Book Issued Successfully....... \n")
            print("Go To Show Issued Books To See Your Books.........")
            
        }else{
            print("Sorry...The Book you entered is unavailable")
        }
    }
    
    
    

}
