//
//  main.swift
//  Book
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


let dataHelper = DataHelper()
let IssueBook = IssueBooks()

let login = User()
login.login()

let UserName = ["Alay"]
let UserPassword = ["1234"]

if(login.name == UserName[0] && login.password == UserPassword[0]){


var choice = 1
while choice != 4 {
    
    print("\n----What would you like to do today !----")
    print("\t 1 : Show Books ")
    print("\t 2 : Issue Book ")
    print("\t 3 : Show Issued Books ")
    print("\t 4 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        print("Code to display list of books")
        dataHelper.displayBooks()
    case 2:
        print("Code to issue a book")
        IssueBook.addBooks()
    case 3:
        print(IssueBook.displayData())
    case 4:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
}

}
else{
    print("Sorry")
}

