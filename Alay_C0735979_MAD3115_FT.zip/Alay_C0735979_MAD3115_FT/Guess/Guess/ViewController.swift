//
//  ViewController.swift
//  Guess
//
//  Created by MacStudent on 2018-08-17.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var MyTextField1: UITextField!
    
    @IBOutlet weak var MyLabel1: UILabel!
    
    @IBOutlet weak var MyLabel2: UILabel!
    
    @IBOutlet weak var MyLabel3: UILabel!
    
    
    
    var ranNo  : Int!
    var firstValue : Int!
    var count = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        MyLabel1.isHidden = true
        MyLabel2.isHidden = true
        MyLabel3.isHidden = true
        
        ranNo = Int(arc4random()%10)
     
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func MyButton1(_ sender: Any) {
        
        MyLabel1.isHidden = false
        MyLabel2.isHidden = false
        MyLabel3.isHidden = false
        
        let firstValue = Int(MyTextField1.text!)

    
        repeat {
    
        if firstValue != nil {
        
        MyLabel2.text = " you Guessed \(firstValue ?? 00)."
        
        if firstValue == ranNo {
            MyLabel1.text = "you Won !!"
            
        }
        else {
            MyLabel1.text = "Sorry Try Again :("
            
            if firstValue! < ranNo  {
            
                MyLabel2.text = "\(firstValue ?? 00) Lower then My number"
            
            }else {
                MyLabel2.text = "\(firstValue ?? 00) Greater then My number"
            }
            
           
            
            count = count - 1
            MyLabel3.text = "\(count) Attemp Left..."
            
            if count == 1  {
                
                MyLabel1.text = "Sorry You Lost The Game :("
                MyLabel2.text = "Press Reset To Play Again.."
               MyLabel3.isHidden = true
                
            }
        
        }
        }
        else {
        
            MyLabel1.text = "Please Enter a Number"
            
        
        }
            
    
        
        } while count <= 0
        
        
    }
    
    
    @IBAction func Button2(_ sender: Any) {
        
        MyLabel1.isHidden = true
        MyLabel2.isHidden = true
        MyLabel3.isHidden = true
        MyTextField1.text = nil
        ranNo = Int(arc4random()%10)
        
    }
    
    
    
    @IBAction func Button3(_ sender: Any) {
        
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let result = mainSB.instantiateViewController(withIdentifier: "Result")
        navigationController?.pushViewController(result, animated: true)    }
    

}

