//
//  Logic.swift
//  Guess
//
//  Created by MacStudent on 2018-08-17.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

let var answer = randomIntBetween(0,high: 100)

var turn = 1

while(true){
    
}

