package com.example.macstudent.mygrocery;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

public class AddProActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

        Spinner spnProName, spnProCategory;

        String ProCategory [] = {"Milks","Juices","Eggs","Cold Drinks","Bread","Spices","Wafers"};

        String ProName[] = {"2% Natural Milk","3% natural Milk", "Slim Milk",
                            "Real Apple Juice","Real Orange","Tropicana Mix Fruit juice",
                            "Brown Eggs","White Eggs",
                            "Sprite","Coke","Coke Zero","cream Soda","Canada Dry","Brio","Root Beer",
                            "Brown Breads","White Breads","Multi Grain Breads",
                            "Salt","Red Chili","Turmik","Garlic Paste","Chilli Paste",
                            "Lays","Daritos","Totrils","Haldhiram","Raffels"};

        int price [] = {2,4,5,6,7,9,15};

        TextView txtAmount;

    String selectedProName, selectedProCategory;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_pro);

        spnProName = findViewById(R.id.spnProName);
        ArrayAdapter ProNameAdp = new ArrayAdapter(this,android.R.layout.simple_spinner_item,ProName);
        ProNameAdp.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spnProName.setOnItemClickListener(this);

        spnProCategory = findViewById(R.id.spnProCategory);
        ArrayAdapter ProcategoryAdp = new ArrayAdapter(this,android.R.layout.simple_spinner_item,ProName);
        ProcategoryAdp.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spnProCategory.setOnItemClickListener(this);

        txtAmount = findViewById(R.id.txtAmount);


    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

        if(adapterView.getId() == spnProName.getId()){
            selectedProName = ProName[position];
        }else if(adapterView.getId() == spnProCategory.getId()){
            selectedProCategory = ProCategory[position];
        }

    }

    @Override
    public void onClick(View v) {

    }
}
