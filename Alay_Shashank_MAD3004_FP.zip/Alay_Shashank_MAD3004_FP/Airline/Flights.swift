//
//  flights.swift
//  Airline
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flights{
    
    var flightID : Int?
    var flightName : String?
    var flightFrom : String?
    var flightTo : String?
    var flightSchedule : String?
    var flightPilot : String?
    var flightUnitPrice : Double?
    
    //Getter - Setter
    var getFlightFrom : String?{
        get { return self.flightFrom}
        set {self.flightFrom = newValue}
    }
    var getFlightTo : String?{
        get { return self.flightTo}
        set {self.flightTo = newValue}
    }

    init() {
       self.flightID = 0123
       self.flightName = "Unknown"
      self.flightFrom = "Unknown"
      self.flightTo = "Unknown"
      self.flightSchedule = "Unknown"
    self.flightPilot = "Unknown"
     self.flightUnitPrice = 0.0
    }
    
    
    init (flightID : Int, flightName : String, flightFrom : String, flightTo : String, flightSchedule : String, flightPilot : String, flightUnitPrice : Double) {
        
        self.flightID = flightID
        self.flightName = flightName
        self.flightFrom = flightFrom
        self.flightTo = flightTo
        self.flightSchedule = flightSchedule
        self.flightPilot = flightPilot
         self.flightUnitPrice = flightUnitPrice    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.flightID != nil{
           returnData += "\n Flight ID : \(self.flightID ?? 0)"
        }
        if self.flightName != nil{
            returnData += "\n Flight Name : " + self.flightName!
        }
        if self.flightFrom != nil{
            returnData += "\n Flight from : " + self.flightFrom!
        }
        if self.flightTo != nil{
            returnData += "\n Flight To : " + self.flightTo!
        }
        if self.flightSchedule != nil{
            returnData += "\n Flight Schedule : " + self.flightSchedule!
        }
        if self.flightPilot != nil{
            returnData += "\n Flight Pilot : " + self.flightPilot!
        }
    
        if self.flightUnitPrice != nil{
            returnData += "\n Flight Seat Price : \(self.flightUnitPrice ?? 0.0)"
        }
        return returnData
    }
    
    
}


