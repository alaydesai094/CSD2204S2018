
//  Airline
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//
import Foundation

typealias revItem = (flightID: Int, Flights: Flights,seat: Int)

class Order: Customer{
    private var orderID : Int
    private var orderDate : Date
    private var orderStatus : OrderStatusList?
    private var orderProducts : [revItem]
    private var dataHelper = DataHelper()
    
    var OrderID : Int{
        get { return self.orderID }
        set{ self.orderID = newValue}
    }
    var OrderDate : Date{
        get { return self.orderDate }
        set{ self.orderDate = newValue}
    }
    var OrderStatus : OrderStatusList?{
        get { return self.orderStatus ?? OrderStatusList.NoOrder }
        set{ self.orderStatus = newValue}
    }
    
    //computed property
    var orderAmount: Double?{
        get{
            var amount = 0.0
            if !self.orderProducts.isEmpty{
                for (_, prod, qty) in self.orderProducts{
                    amount += prod.flightUnitPrice! * (Double)(qty)
                }
            }
            return amount
        }
    }
    
    override init(){
        self.orderID = 0
        self.orderDate = DateFormatter().date(from: "")!
        self.orderStatus = OrderStatusList.NoOrder
        self.orderProducts = []
        super.init()
    }
    
    override func displayData() -> String {
        var returnData = ""
        
        
        
        returnData += "\n ------| Flight Details |--------------- \n"
        
        returnData += "\n Booking ID : \(self.OrderID)"
        returnData += "\n booking Date : \(self.OrderDate ) \n "
        
        if !self.orderProducts.isEmpty{
            for (_, product, qty) in self.orderProducts{
                returnData += "\n \t \(product.displayData())"
                returnData += "\n \t No. of Seats : \(qty)"
            }
        }else{
            returnData += "\n No Flight in the order"
        }
      
        returnData += "\n Booking Status : \(self.OrderStatus ?? OrderStatusList.NoOrder)"
         returnData += "\n ------------------------------------------------ \n"
        returnData += "\n Total Amount : \(self.orderAmount  ?? 0.0)"
        returnData += "\n ------------------------------------------------ \n"
        return returnData
    }
    
    func addOrder(){
        dataHelper.displayFlights()
        print("\n ---------------------------------------------------------- \n")
        print("Enter Flight ID to choose any Flight from the list : ")
        let selectedProductID : Int = (Int)(readLine()!)!
        
        if let selectedProduct = dataHelper.searchflight(flightID: selectedProductID){
            self.OrderID = selectedProductID
            self.OrderDate = Date()
            
            print("Enter the No. of seats You Want to Book : ")
            let qty : Int = (Int)(readLine()!) ?? 1
            
            print("\n -------| Booking Successful... |-------- \n  ")
            
            print("Go to Show My booking to see the Details.... ")
            print("\n ---------------------------------------------------------- \n")
            self.orderProducts += [(flightID: selectedProductID, Flights: selectedProduct, seat: qty)]
            self.OrderStatus = OrderStatusList.Placed
            
        }else{
            print("Sorry...The product you entered is unavailable")
        }
    }
   /*
    func cancelOrder(){
        if !orderProducts.isEmpty {
            print("Review your order \n \(self.displayData())")
            
            print("Please enter product ID to remove from the order : ")
            let selectedProductID : Int = (Int)(readLine()!)!
            var productIndex = -1
            
            for (index, item) in self.orderProducts.enumerated(){
                if (item.productID == selectedProductID){
                    productIndex = index
                }
            }
            
            if productIndex != -1{
                self.orderProducts.remove(at: productIndex)
                print("The product is removed from your order")
            }
        }else{
            print("You have no item in your order")
        }
 */
    }
// }

