//
//  main.swift
//  Airline
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

  let order = Order()


print("----------------------------------------------------- \n")
print("Fly High Bookings \n")
print("----------------------------------------------------- \n")
print("Enter Your Details to Register with Us... \n")

//Registration Details Request
var customer = Customer()
customer.registerUser()

// print(customer.displayData())


print("----------------------------------------------------- \n")

print("Welcome to Our Application :  \(customer.getCustomerName ?? "Guest") \n " )
print("----------------------------------------------------- ")

var choice = 1

while choice != 6{
    print("\n----|  Main Menu |---- \n")
    print("\t 1 : Browse Flights ")
    print("\t 2 : Book flights ")
    print("\t 3 : Show My Booking ")
    print("\t 4 : Update Booking ")
    print("\t 5 : My Profile ")
    print("\t 6 : Exit \n ")
    
    print("Please choose from options 1-5 to proceed... \n")
    
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
      
        print("----------------------------------------------------- \n")
        print("\n----|  Browse Flights  |---- \n")
        print("----------------------------------------------------- \n")
        
        // view Flight details
         
         let dataHelper = DataHelper()
         dataHelper.displayFlights()
    
    case 2:
        print("----------------------------------------------------- \n")
        print("\n----|  Book Flights  |---- \n")
        print("----------------------------------------------------- \n")
        
        order.addOrder()
    case 3:
        print("----------------------------------------------------- \n")
        print("\n----|  My Bookings  |---- \n")
        print("----------------------------------------------------- \n")
        
         print(order.displayData())
        
    case 4:
        print("----------------------------------------------------- \n")
        print("\n----|  Update Booking  |---- \n")
        print("----------------------------------------------------- \n")
        
        
    case 5:
        print("----------------------------------------------------- \n")
        print("\n----| My Profile  |---- \n")
        print("----------------------------------------------------- \n")
        
        print(customer.displayData())
     case 6:
        print("Thank you.... ")
        print("Have a safe flight.... ")
        print("Signing Out....")
        print("Bye....")
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
}




